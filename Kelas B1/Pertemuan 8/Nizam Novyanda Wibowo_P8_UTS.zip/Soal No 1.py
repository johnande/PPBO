def mil_ke_kilometer(mil):
    return mil * 1.60934
    
input_jarak = int(input("Masukkan jarak dalam mil: "))
kilometer = mil_ke_kilometer(input_jarak)
print(f"{input_jarak} mil = {kilometer} kilometer")
