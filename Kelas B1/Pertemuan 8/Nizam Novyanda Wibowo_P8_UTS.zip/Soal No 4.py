class Rekening:
  def __init__(self, nama, no_rekening, saldo):
    self.nama = nama
    self.no_rekening = no_rekening
    self.saldo = saldo
    
class Nasabah(Rekening):
  def __init__(self, nama, no_rekening, saldo):
    super().__init__(nama, no_rekening, saldo)

  def tampilkan_data_nasabah(self):
    print(f"Nama: {self.nama}")
    print(f"No. Rekening: {self.no_rekening}")
    print(f"Saldo: {self.saldo:.2f}")

def main():
  nasabah1 = Nasabah("Budi", "5555", 500000)
  nasabah2 = Nasabah("Wati", "6666", 2000000.00)

  nasabah1.tampilkan_data_nasabah()
  print()
  nasabah2.tampilkan_data_nasabah()
  print()


if __name__ == "__main__":
  main()
