class Rekening:
  def __init__(self, nama, no_rekening, saldo):
    self.nama = nama
    self.no_rekening = no_rekening
    self.saldo = saldo
  
  def setor_tunai(self, nominal):
    self.saldo += max(0, nominal)
    print(f"Setor tunai Rp{self.saldo - self.saldo + nominal:,.2f} berhasil.")

  def tarik_tunai(self, nominal):
    self.saldo -= min(self.saldo, nominal)
    print(f"Tarik tunai Rp{self.saldo + nominal - self.saldo:,.2f} berhasil.")
    
class Nasabah(Rekening):
  def __init__(self, nama, no_rekening, saldo):
    super().__init__(nama, no_rekening, saldo)

  def tampilkan_data_nasabah(self):
    print(f"Nama: {self.nama}")
    print(f"No. Rekening: {self.no_rekening}")
    print(f"Saldo: {self.saldo:.2f}")

def main():
  nasabah1 = Nasabah("Budi", "5555", 500000)
  nasabah2 = Nasabah("Wati", "6666", 2000000.00)

  print("\n Transaksi Nasabah 1 ")
  nasabah1.setor_tunai(1000000.00)
  nasabah1.tampilkan_data_nasabah()

  print("\n Transaksi Nasabah 2 ")
  nasabah2.tarik_tunai(1000000.00)
  nasabah2.tampilkan_data_nasabah()


if __name__ == "__main__":
  main()
