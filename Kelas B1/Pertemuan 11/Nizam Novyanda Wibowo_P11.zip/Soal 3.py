class Model(object):
    services = {
        'email': {'number': 1000, 'price': 2,},
        'sms': {'number': 1000, 'price': 10,},
        'voice': {'number': 1000, 'price': 15,},
    }

class View(object):
    def list_services(self, services):
        print("Services Provided:")
        for svc in services:
            print(f"{svc}")

    def list_pricing(self, services):
        print("Pricing for Services:")
        for svc in services:
            print(f"For every 1000 {svc} message you pay $ {Model.services[svc]['price']}")

class View2(object):
    def list_services(self, services):
        print("Layanan yang disediakan:")
        for svc in services:
            print(f"{svc}")

    def list_pricing(self, services):
        print("Tarif tiap layanan:")
        for svc in services:
            print(f"Untuk setiap 1000 {svc} anda membayar $ {Model.services[svc]['price']}")

class Controller(object):
    def __init__(self):
        self.view = View() 
        self.model = Model()

    def get_services(self):
        services = self.model.services.keys()
        self.view.list_services(services)

    def get_pricing(self):
        services = self.model.services.keys()
        self.view.list_pricing(services)

    def bid_price(self):
        while True:
            service_choice = input("Enter the service you want to bid (email, sms, or voice): ")
            if service_choice.lower() in self.model.services:
                break
            else:
                print("Invalid service choice. Please enter email, sms, or voice.")

        new_price = float(input("Enter the price you want: $"))
        if new_price > 0:
            self.model.services[service_choice]['price'] = new_price
            print("Price according to your bid!")
            self.get_pricing()
        else:
            print("Invalid price. Please enter a positive number.")

controller = Controller()
controller.get_services()
controller.get_pricing()
controller.bid_price()
