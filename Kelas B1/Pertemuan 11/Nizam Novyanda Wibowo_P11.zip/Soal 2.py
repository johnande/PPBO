class Model(object):
    services = {
        'email': {'number': 1000, 'price': 2},
        'sms': {'number': 1000, 'price': 10},
        'voice': {'number': 1000, 'price': 15},
    }

class View(object):
    def list_services(self, services):
        print("Services Provided:")
        for svc in services:
            print(f"{svc}")

    def list_pricing(self, services):
        print("Pricing for Services:")
        for svc in services:
            print(f"For every 1000 {svc} message you pay $ {Model.services[svc]['price']}")

class View2(object):
    def list_services(self, services):
        print("Layanan yang disediakan:")
        for svc in services:
            print(f"{svc}")

    def list_pricing(self, services):
        print("Tarif tiap layanan:")
        for svc in services:
            print(f"Untuk setiap 1000 {svc} anda membayar $ {Model.services[svc]['price']}")

class Controller(object):
    def __init__(self, view):
        self.view = view
        self.model = Model()

    def get_services(self):
        services = self.model.services.keys()
        self.view.list_services(services)

    def get_pricing(self):
        services = self.model.services.keys()
        self.view.list_pricing(services)

def main():
    while True:
        language_choice = input("What language do you choose? [1] English [2] Indonesia: ")
        if language_choice == "1":
            view = View()
            break
        elif language_choice == "2":
            view = View2()
            break
        else:
            print("Error, choose the language number!")

    controller = Controller(view)
    controller.get_services()
    controller.get_pricing()

if __name__ == "__main__":
    main()
