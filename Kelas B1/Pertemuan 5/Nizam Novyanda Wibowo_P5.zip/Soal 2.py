class Hewan:
    def __init__(self, nama):
        self.nama = nama
    def berkaki(self):
        raise
class Anjing(Hewan):
    def berkaki(self):
        return f"{self.nama} Berkaki 4"
class Kucing(Hewan):
    def berkaki(self):
        return f"{self.nama} Berkaki 4"
def hewan_berkaki(hewan):
    print(hewan.berkaki())
dog = Anjing("Milo")
cat = Kucing("Mio")
hewan_berkaki(dog)
hewan_berkaki(cat)