class Hewan:
    def berkaki(self):
        raise

class Kucing(Hewan):
    def berkaki(self):
        print("Berkaki 4")

class Anjing(Hewan):
    def berkaki(self):
        print("Berkaki 4")

class Burung (Hewan):
    def berkaki(self):
        print("Berkaki 2")

def tampilkan_jumlah_kaki(hewan):
    hewan.berkaki()

kucing = Kucing()
anjing = Anjing()
burung = Burung()
hewan_list = [kucing, anjing, burung]

for hewan in hewan_list:
    tampilkan_jumlah_kaki(hewan)