class Barang:
    def __init__(self, merek, harga_satuan):
        self.merek = merek
        self.harga_satuan = harga_satuan # dalam ribu
    
    def __eq__(self, other):
        return self.harga_satuan == other.harga_satuan
    
    def __lt__(self, other):
        return self.harga_satuan < other.harga_satuan
    
    def __gt__(self, other):
        return self.harga_satuan > other.harga_satuan

redmi10 = Barang("Redmi 10", 2140)
pocoX4Pro = Barang("Poco X4 Pro", 3499)

print(f"Redmi 10 sama harganya dengan Poco X4 Pro? {redmi10 == pocoX4Pro}")
print(f"Redmi 10 lebih murah daripada Poco X4 Pro? {redmi10 < pocoX4Pro}")
print(f"Redmi 10 lebih mahal daripada Poco X4 Pro? {redmi10 > pocoX4Pro}")
