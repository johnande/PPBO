niu = int(input('Masukkan NIU :'))
nilai_tugas = int(input("Masukkan nilai tugas :"))
nilai_laporan = int(input('Masukkan nilai laporan :'))
rata_rata = (nilai_tugas * nilai_laporan) / 2

if rata_rata < 40:
    print("Nilai akhir = K")
else:
    nilai_ujian = int(input("Masukkan nilai ujian :"))
    nilai_akhir = (nilai_tugas * 0.25) + (nilai_laporan * 0.25) + (nilai_ujian * 0.5)
    if 80 <= nilai_akhir <= 100:
        nilai_huruf = "A"
    elif 70 <= nilai_akhir <= 80:
        nilai_huruf ="B"
    elif 60 <= nilai_akhir <= 70:
        nilai_huruf = "C"
    elif 50 <= nilai_akhir <= 60:
        nilai_huruf = "D"
    else:
        nilai_huruf = "E"
print(f"Nilai akhir: {nilai_huruf}")
