angka = int(input("Masukkan angka: "))
for i in range(angka, -1, -1):
    print(i, end= ' ')