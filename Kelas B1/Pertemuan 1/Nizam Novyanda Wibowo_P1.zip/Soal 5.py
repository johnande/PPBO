import math
jari_jari = float(input("Masukkan jari-jari lingkaran:"))
luas = math.pi * jari_jari **2
keliling = 2 * math.pi * jari_jari
print("Luas lingkaran:", luas)
print("Keliling lingkaran:", keliling)