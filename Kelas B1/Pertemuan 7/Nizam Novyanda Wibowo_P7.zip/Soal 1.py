class Passenger:
  TITLES = ("Mr", "Mrs", "Ms")
  def __init__(self, title, fname, lname):
    if title not in self.TITLES:
      raise ValueError("%s is not a valid title." % title)
    self.title = title
    self.fname = fname
    self.lname = lname

pl = Passenger("Mr", "Kiewlamphone", "Souvanlith")
print(pl.TITLES)
print(Passenger.TITLES)
print(pl.title)
print(Passenger.title)