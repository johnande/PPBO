class Introduction:
    def __init__(self, func):
        self.func = func
    def __call__(self, name):
        print(f"Hello, my name is {name}")

@Introduction
def greet(name):
    pass
vino = "Vino"
greet(vino)