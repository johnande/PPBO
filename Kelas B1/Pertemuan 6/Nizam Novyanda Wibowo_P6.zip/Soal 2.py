from abc import ABC, abstractmethod

class BangunRuang(ABC):
    def __init__(self, nama):
        self.nama = nama
    @abstractmethod
    def volume(self):
        pass
    @abstractmethod
    def luas_permukaan(self):
        pass
        
class Kubus(BangunRuang):
    def __init__(self, sisi):
        super().__init__("Kubus")
        self.sisi = sisi
        
    def volume(self):
        return self.sisi**3
        
    def luas_permukaan(self):
        return 6 * self.sisi**2

class Balok(BangunRuang):
    def __init__(self, panjang, lebar, tinggi):
        super().__init__("Balok")
        self.panjang = panjang
        self.lebar = lebar
        self.tinggi = tinggi
        
    def volume(self):
        return self.panjang * self.lebar * self.tinggi
    
    def luas_permukaan(self):
        return 2 * (self.panjang * self.lebar + self.lebar * self.tinggi + self.tinggi * self.panjang)

kubus = Kubus(5)
balok = Balok(3, 4, 5)

print(f"Nama Bangun Ruang: {kubus.nama}")
print(f"Volume: {kubus.volume()}")
print(f"Luas Permukaan: {kubus.luas_permukaan()}")

print(f"\nNama Bangun Ruang: {balok.nama}")
print(f"Volume: {balok.volume()}")
print(f"Luas Permukaan: {balok.luas_permukaan()}")