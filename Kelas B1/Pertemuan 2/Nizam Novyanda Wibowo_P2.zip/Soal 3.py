class Persegi:
  def __init__(self, sisi):
    self.sisi = sisi
  def hitung_luas(self):
    return self.sisi * self.sisi
  def hitung_keliling(self):
    return 4 * self.sisi

persegi = Persegi(8)
luas = persegi.hitung_luas()
print(f"Luas Persegi: {luas}")
keliling = persegi.hitung_keliling()
print(f"Keliling Persegi: {keliling}")