class Motor:
    def __init__(self, merk, tahun):
        self.merk = merk
        self.tahun = tahun
    def tampilkan_info(self):
        print(f"Motor saya adalah {self.merk} tahun {self.tahun}.")

motor_saya = Motor("Honda", 2023)
motor_saya.tampilkan_info()