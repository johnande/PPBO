class Manusia:
    def __init__(self, nama, umur):
        self.nama = nama
        self.umur = umur
    def tampilkan_informasi(self):
        print(f"Nama saya {self.nama}, umur saya {self.umur} tahun")

def main():
    nama = input("Masukkan nama: ")
    umur = input("Masukkan umur: ")
    orang = Manusia(nama, umur)
    orang.tampilkan_informasi()

if __name__ == "__main__":
  main()