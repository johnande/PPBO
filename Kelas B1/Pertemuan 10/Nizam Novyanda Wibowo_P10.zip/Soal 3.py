from abc import ABC, abstractmethod

class University(ABC):
    @abstractmethod
    def name(self):
        pass

    @abstractmethod
    def located(self):
        pass

    @abstractmethod
    def since(self):
        pass

class UGM(University):
    def name(self):
        print("Gadjah Mada University.")

    def located(self):
        print("Gadjah Mada University is located in Yogyakarta, Indonesia.")

    def since(self):
        print("Gadjah Mada University was established since 1949.")

class UI(University):
    def name(self):
        print("Indonesia University.")

    def located(self):
        print("Indonesia University is located in Depok, Indonesia.")

    def since(self):
        print("Indonesia University was established since 1950.")

class UNDIP(University):
    def name(self):
        print("Diponegoro University.")

    def located(self):
        print("Diponegoro University is located in Semarang, Indonesia.")

    def since(self):
        print("Diponegoro University was established since 1957.")

class UniversityFactory:
    def get_university(self, university_name):
        university_name = university_name.lower()
        if university_name == "ugm":
            return UGM()
        elif university_name == "ui":
            return UI()
        elif university_name == "undip":
            return UNDIP()
        else:
            raise ValueError("Invalid university name. Please choose UGM, UI, or UNDIP.")

def main():
    factory = UniversityFactory()
    university_name = input("Which university you want to search (UGM, UI, UNDIP): ")
    try:
        university = factory.get_university(university_name)
        university.name()
        university.located()
        university.since()
    except ValueError as e:
        print(e)

if __name__ == "__main__":
    main()
