class Karyawan(Orang):
    TETAP, TIDAK_TETAP = range(2)
    def __init__(self, nama_depan, nama_belakang, nomer_id, status_karyawan):
        super().__init__(nama_depan, nama_belakang, nomer_id)
        self.status_karyawan = status_karyawan
        if status_karyawan == 0:
            self.status_karyawan = "TETAP"
        else:
            self.status_karyawan = "TIDAK_TETAP"