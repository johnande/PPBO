class Orang:
    def __init__(self,nama_depan, nama_belakang, nomer_id):
        self.nama_depan = nama_depan
        self.nama_belakang = nama_belakang
        self.nomer_id = nomer_id

class Mahasiswa(Orang):
    SARJANA, MASTER, DOKTOR = range(3)
    def __init__(self, nama_depan, nama_belakang, nomer_id, jenjang):
        super().__init__(nama_depan, nama_belakang, nomer_id)
        self.jenjang = jenjang
        self.matkul = []
        if jenjang == 0:
            self.jenjang = "Sarjana"
        elif jenjang == 1:
            self.jenjang = "Master"
        elif jenjang == 2:
            self.jenjang = "Doktor"
    def enrol(self, mata_kuliah):
        self.matkul.append(mata_kuliah)