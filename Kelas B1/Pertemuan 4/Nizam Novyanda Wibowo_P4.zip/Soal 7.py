class Pelajar:
    def __init__(self):
        self.matkul = []
    def enrol(self, mata_kuliah):
        self.matkul.append(mata_kuliah)