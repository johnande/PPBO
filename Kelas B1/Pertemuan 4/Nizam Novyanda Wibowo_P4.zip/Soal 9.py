class asdos(Orang,Pelajar,Pengajar):
    def __init__(self,nama_depan, nama_belakang, nomor_ID):
        super(). __init__(nama_depan, nama_belakang, nomor_ID)

uswatun = asdos("Uswatun", "Hasanah", "456456")
uswatun.enrol("Big Data")
uswatun.mengajar("Kecerdasan Artifisial")