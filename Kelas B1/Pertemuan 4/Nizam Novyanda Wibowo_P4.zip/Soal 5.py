class Mahasiswa:
    def __init__(self, nama_depan, nama_belakang,  nomer_id, jenjang):
        self.nama_depan = nama_depan
        self.nama_belakang = nama_belakang
        self.nomer_id = nomer_id
        self.jenjang = jenjang
        self.matkul = []

    def enrol(self, matkul):
        self.matkul.append(matkul)
        
bowo = Mahasiswa("Bowo", "Nugroho", "987654", "SARJANA")

bowo.enrol("Basis Data")
print("Nama Lengkap:", bowo.nama_depan, bowo.nama_belakang)
print("Nomer ID:", bowo.nomer_id)
print("Jenjang:", bowo.jenjang)
print("Mata Kuliah yang Diambil:", bowo.matkul)