uswatun = asdos("Uswatun", "Hasanah", "456456")
uswatun.enrol("Big Data")
uswatun.mengajar("Kecerdasan Artifisial")

print("Nama Lengkap:", uswatun.nama_depan, uswatun.nama_belakang)
print("Nomor ID:", uswatun.nomor_id)
print("Mata Kuliah", uswatun.matkul)
print("mengajar", uswatun.matkul_diajar)