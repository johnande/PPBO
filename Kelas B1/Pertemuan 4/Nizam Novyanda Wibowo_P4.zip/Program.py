class Orang:
    def __init__(self, nama_depan, nama_belakang, nomer_id):
        self.nama_depan = nama_depan
        self.nama_belakang = nama_belakang
        self.nomer_id = nomer_id
        self.matkul = []
        self.matkul_diajar = []

class Mahasiswa(Orang):
    SARJANA, MASTER, DOKTOR = range(3)
    def __init__(self, nama_depan, nama_belakang, nomer_id, jenjang):
        super().__init__(nama_depan, nama_belakang, nomer_id)
        self.jenjang = jenjang
        self.matkul = []
        if jenjang == 0:
            self.jenjang = "Sarjana"
        elif jenjang == 1:
            self.jenjang = "Master"
        elif jenjang == 2:
            self.jenjang = "Doktor"

    def enrol(self, mata_kuliah):
        self.matkul.append(mata_kuliah)

class Karyawan(Orang):
    TETAP, TIDAK_TETAP = range(2)
    def __init__(self, nama_depan, nama_belakang, nomer_id, status_karyawan):
        super().__init__(nama_depan, nama_belakang, nomer_id)
        self.status_karyawan = status_karyawan
        if status_karyawan == 0:
            self.status_karyawan = "TETAP"
        else:
            self.status_karyawan = "TIDAK_TETAP"

class Dosen(Karyawan):
    def __init__(self, nama_depan, nama_belakang, nomer_id, status_karyawan):
        super().__init__(nama_depan, nama_belakang, nomer_id, status_karyawan)
        self.matkul_diajar = []
    def mengajar(self, mata_kuliah):
        self.matkul_diajar.append(mata_kuliah)

bowo = Mahasiswa("Bowo", "Nugroho", "987654", Mahasiswa.SARJANA)
bowo.enrol("Basis Data")
print("Nama Lengkap:", bowo.nama_depan, bowo.nama_belakang)
print("Nomer ID:", bowo.nomer_id)
print("Jenjang:", bowo.jenjang)
print("Mata Kuliah yang Diambil:", bowo.matkul)

rizki = Dosen("Rizki", "Setiabudi", "456789", Karyawan.TETAP)
rizki.mengajar("Statistik")
print("Nama Lengkap:", rizki.nama_depan, rizki.nama_belakang)
print("Nomer ID:", rizki.nomer_id)
print("Status Karyawan:", rizki.status_karyawan)
print("Mata Kuliah yang Diajar:", rizki.matkul_diajar)

class Pelajar:
    def __init__(self):
        self.matkul = []
    def enrol(self, mata_kuliah):
        self.matkul.append(mata_kuliah)

class Pengajar:
    def __init__(self):
        self.matkul_diajar = []
    def mengajar(self, mata_kuliah):
        self.matkul_diajar.append(mata_kuliah)

class asdos(Orang, Pelajar, Pengajar):
    def __init__(self, nama_depan, nama_belakang, nomor_ID):
        super().__init__(nama_depan, nama_belakang, nomor_ID)

uswatun = asdos("Uswatun", "Hasanah", "456456")
uswatun.enrol("Big Data")
uswatun.mengajar("Kecerdasan Artifisial")
print("Nama Lengkap:", uswatun.nama_depan, uswatun.nama_belakang)
print("Nomer ID:", uswatun.nomer_id)
print("Mata Kuliah", uswatun.matkul)
print("Mengajar:", uswatun.matkul_diajar)