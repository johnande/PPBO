class Dosen:
    def __init__(self, nama_depan, nama_belakang,  nomer_id, status_karyawan):
        self.nama_depan = nama_depan
        self.nama_belakang = nama_belakang
        self.nomer_id = nomer_id
        self.status_karyawan = status_karyawan
        self.matkul_diajar = []

    def mengajar(self, matkul):
        self.matkul_diajar.append(matkul)

rizki = Dosen("Rizki", "Setiabudi", "456789", "Karyawan.TETAP")
rizki.mengajar("Statistik")

print("Nama Lengkap:", rizki.nama_depan, rizki.nama_belakang)
print("Nomer ID:", rizki.nomer_id)
print("Status Karyawan:", rizki.status_karyawan)
print("Mata Kuliah yang Diajar:", rizki.matkul_diajar)