class Pengajar:
    def __init__(self):
        self.matkul_diajar = []
    def mengajar(self, mata_kuliah):
        self.matkul_diajar.append(mata_kuliah)