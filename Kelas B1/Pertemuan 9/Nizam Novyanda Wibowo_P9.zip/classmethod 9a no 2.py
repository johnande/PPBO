class Kendaraan:

  def __init__(self, merek, model, tahun):
    self.merek = merek
    self.model = model
    self.tahun = tahun

  @classmethod
  def from_string(cls, kendaraan_string):
    merek, model, tahun = kendaraan_string.split(',')
    return cls(merek, model, tahun)

  def get_info(self):
    return f"{self.merek} {self.model} ({self.tahun})"

kendaraan_string1 = "Toyota,Innova,2020"
kendaraan1 = Kendaraan.from_string(kendaraan_string1)
print(kendaraan1.get_info())

kendaraan_string2 = "Honda,Brio,2020"
kendaraan2 = Kendaraan.from_string(kendaraan_string2)
print(kendaraan2.get_info())
