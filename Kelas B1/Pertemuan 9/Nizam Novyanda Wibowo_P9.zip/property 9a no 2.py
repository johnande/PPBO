class Barang:
  def __init__(self, nama, harga, diskon):
    self.nama = nama
    self.harga = harga
    self.diskon = diskon

  @property
  def harga_diskon(self):
    diskon_persen = self.diskon / 100
    potongan_diskon = self.harga * diskon_persen
    harga_akhir = self.harga - potongan_diskon
    return harga_akhir

laptop = Barang("Asus Zenbook", 10000000, 10)
print(f"Harga {laptop.nama} setelah diskon: Rp{laptop.harga_diskon:,}")
