from collections import namedtuple
Koordinat = namedtuple('Koordinat', ['x', 'y'])
titik1 = Koordinat(x=2, y=4)

print(f"Elemen dengan indeks: {titik1[0]}, {titik1[1]}")
print(f"Elemen dengan field name: {titik1.x}, {titik1.y}")
print(f"Elemen dengan getattr: {getattr(titik1, 'x')}, {getattr(titik1, 'y')}")
