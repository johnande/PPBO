class Persegi:
  def __init__(self, sisi):
    self.sisi = sisi

  @staticmethod
  def hitung_luas(sisi):
    return sisi * sisi

sisi = 10
luas = Persegi.hitung_luas(sisi)
print(f"Luas persegi dengan sisi {sisi} adalah {luas}")
