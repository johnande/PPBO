from collections import namedtuple
Orang = namedtuple("Orang", "nama anak")

def add_tampilkan_info(cls):
    def tampilkan_info(self):
        print("Nama:",self.nama)
        print("Nama anak:")
        for i, anak in enumerate(self.anak):
            print(f"{i+1}.{anak}")
    cls.tampilkan_info = tampilkan_info
    return cls

Orang = add_tampilkan_info(Orang)

john = Orang("John Doe", ["Jimmy", "Tina"])
print(john)
print(id(john.anak))

john = john._replace(anak= john.anak + ['Timmy'])

print(john)
print(id(john.anak))
john.tampilkan_info()