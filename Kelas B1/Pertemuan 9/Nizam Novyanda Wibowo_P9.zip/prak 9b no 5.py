from collections import namedtuple
Mahasiswa = namedtuple('Mahasiswa', 'nim nama jurusan')

mahasiswa1 = Mahasiswa(nim=12345, nama="Linda", jurusan="Kedokteran")
mahasiswa2 = Mahasiswa(nim=678910, nama="Vino", jurusan="Teknik Sipil")

print(f"Data Mahasiswa: {mahasiswa1.nim} - {mahasiswa1.nama} ({mahasiswa1.jurusan})")
print(f"Data Mahasiswa: {mahasiswa2.nim} - {mahasiswa2.nama} ({mahasiswa2.jurusan})")