s = int(input("Masukkan angka:"))

for r in range (s, -1, -1):
        print(r, end='')